//Keenspot/Keenspot Kids Header version 3.0
//Copyright (c) 2001-2018 Kisai c/o Keenspot Entertainment, all rights reserved.
//This script is legally permitted to be redistributed on any site bearing 
//Keenspot advertisements and Keenspot signage. This script may also be 
//sub-licensed to any online comic, or content delivery networks as agreed 
//in writing.
//
//For any questions about the technical operation of this script contact
//Kisai at Keenspot.
var copyurl=window.location.href;

var queryString = {};
copyurl.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function($0, $1, $2, $3) { queryString[$1] = $3; }
);

var barhead=document.getElementsByTagName('head')[0];
var barfinder=document.createElement('script');

barfinder.type="text/javascript";
if(queryString['betamode']=="false"){localStorage.removeItem('betamode');}
if(queryString['betamode']=="true" || localStorage.getItem('betamode')=="true"){
barfinder.src="//www.keenspot.com/ks_headbar.js";
//barfinder.src="http://www.keenspot.com/ks_headbar_test.js";
}else{
barfinder.src="//www.keenspot.com/ks_headbar.js";
}
barhead.appendChild(barfinder);
var geohead=document.getElementsByTagName('head')[0];
var geofinder=document.createElement('script');
var geoloc="";
/*
geofinder.type="text/javascript";
geofinder.src="http://www.keenspot.com/geotest.php";
geohead.appendChild(geofinder);
*/
var hcurrentTime = new Date();
var hmonth = hcurrentTime.getMonth() + 1;
var hday = hcurrentTime.getDate();
var hyear = hcurrentTime.getFullYear();
var headtimer=""+hyear+""+hmonth+""+hday;