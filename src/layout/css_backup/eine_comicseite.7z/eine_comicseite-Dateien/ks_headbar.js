//moving stuff around 20120316
//Keenspot/Keenspot Kids Header version 3.0
//Copyright (c) 2001-2012 Kisai c/o Keenspot Entertainment, all rights reserved.
//This script is legally permitted to be redistributed on any site bearing 
//Keenspot advertisements and Keenspot signage. This script may also be 
//sub-licensed to any online comic, or content delivery networks as agreed 
//in writing.
//
//For any questions about the technical operation of this script contact
//Kisai at Keenspot.

//This script is several pieces by design. The XML files are the ones you should
//change as needed, and leave this script alone as much as possible.

//First understand that the header must exist before the content of the site,
//This means that it needs to exist after <body> but before any other tag.
//On Keenspot ks_header.js is glued to the end of the body tag regardless of any
//other tag as part of setting the margins to zero.

localStorage.removeItem("betamode");
if (top.location != self.location){

//top.location = self.location;

}

function keenSwitch2(url)        
{
    if (url !== '')  {

//	top.location.href = encodeURI(url);
if(true==true || typeof _gaq == "undefined"){
    top.location.href = url;

}else{

 _gaq.push(['kg._link', url]); 
}
    }
}


document.body.style.margin="0px"; // No margin
//Important variables
//document.documentElement.clientHeight; document.documentElement.clientWidth; 
var ksheaderdiv = document.createElement('div');
function buildbar(){
function addtodrop(a,b){
var inopt=new Option(a,b);
try{
kselect.add(inopt,null);
}
catch(e){
kselect.add(inopt);
}

}

ksheaderdiv.setAttribute('id',"kshbar");
ksheaderdiv.style.position="relative";
ksheaderdiv.style.display="block";
ksheaderdiv.style.width="100%";
ksheaderdiv.style.height="32px";
ksheaderdiv.style.top="0px";
ksheaderdiv.style.left="0px";
ksheaderdiv.style.padding="0px";
ksheaderdiv.style.zIndex="250";
ksheaderdiv.style.borderBottom="5px solid white";
ksheaderdiv.style.backgroundColor="#000000";
ksheaderdiv.style.visiblity="visible";


//Header main Logo
var logolink=document.createElement('a');
logolink.setAttribute('href','https://www.keenspot.com?&amp;go=home');
var logoimage=document.createElement('img');
logoimage.setAttribute('width','106');
logoimage.setAttribute('height','32');
logoimage.setAttribute('border','0');
logoimage.style.visiblity="visible";
logoimage.style.display="block";
logoimage.setAttribute('src','//www.keenspot.com/global/header-logo-black.gif');
logolink.appendChild(logoimage);
var logobox = document.createElement('div');
logobox.appendChild(logolink);
logobox.style.position="absolute";
logobox.style.width="106px";
logobox.style.height="32px";
logobox.style.top="0px";
logobox.style.left="0px";
logobox.style.padding="0px";
logobox.style.zIndex="251";
logobox.style.visiblity="visible";
ksheaderdiv.appendChild(logobox);

//Header main promo
var promolink=document.createElement('a');
promolink.setAttribute('href','http://amzn.to/uSyc2P');
promolink.setAttribute('id','psl');
var promoimage=document.createElement('img');
promoimage.setAttribute('id','psi');
promoimage.setAttribute('width','519');
promoimage.setAttribute('height','32');
promoimage.setAttribute('border','0');
promoimage.setAttribute('src','//www.keenspot.com/images/headerbar-amazon1.gif');
promoimage.style.visiblity="visible";
promoimage.style.display="block";
var tpimage=document.createElement('img');
tpimage.setAttribute('id','psti');

tpimage.setAttribute('width','1');
tpimage.setAttribute('height','1');
tpimage.setAttribute('border','0');
tpimage.setAttribute('src','//www.keenspot.com/blank.gif');
tpimage.style.visiblity="visible";
tpimage.style.display="block";

var promobox = document.createElement('div');
promobox.style.position="relative";
promobox.style.width="519px";
promobox.style.height="32px";
promobox.style.top="0px";
//promobox.style.left="88px";
promobox.style.marginLeft="auto";
promobox.style.marginRight="auto";
promobox.style.padding="0px";
promobox.style.zIndex="251";
promobox.style.visiblity="visible";
promobox.style.display="block";
promolink.appendChild(promoimage);
promobox.appendChild(promolink);
promobox.appendChild(tpimage);
ksheaderdiv.appendChild(promobox);


//Header main links
//var klink=document.createElement('a');
//klink.setAttribute('href','http://kids.keenspot.com?&amp;=home');
var mxseconds = new Date().getTime() / 1000;
var kform=document.createElement('form');
kform.setAttribute('action','https://www.keenspot.com/dropdown.php?'+'mxm='+mxseconds);
kform.style.position="absolute";

kform.style.height="1em";
kform.style.width="100%";
kform.style.right="1px";
kform.style.top="4px";
kform.style.textAlign="right";
var kinput=document.createElement('input');
kinput.setAttribute('type','hidden');
kinput.setAttribute('name','domain');
kinput.setAttribute('value','www.keenspot.com');
var kselect=document.createElement('select');
kselect.setAttribute('name','siteIndex');
kselect.setAttribute('onchange','keenSwitch2(this.options[selectedIndex].value);');
var kbox = document.createElement('div');
kbox.style.position="absolute";
kbox.style.width="170px";
kbox.style.height="31px";
kbox.style.top="1px";
kbox.style.right="0px";
kbox.style.padding="0px";
kbox.style.zIndex="252";

kform.appendChild(kinput);
kform.appendChild(kselect);
kbox.appendChild(kform);

ksheaderdiv.appendChild(kbox);
var rndcode=Math.round(new Date().getTime() / 1000);
var selvar=Math.ceil(Math.random() * 3)-1;
selvar=0;

//if(geoloc!="US"){
//selvar="GEONONUS";
//}


//selvar="TIMER";
//selvar=1;


//
if(selvar==0){
//promolink.setAttribute('href','http://amzn.to/uSyc2P');
//promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-amazon1.gif');
//promoimage.setAttribute('alt','Click Here');


//promolink.setAttribute('href','http://bit.ly/1VxFapG');
//promoimage.setAttribute('src','//www.keenspot.com/images/headerbar-keenspotshop1.gif');
//promoimage.setAttribute('alt','Keenspot Shop');

promolink.setAttribute('href','https://bit.ly/2XDeQnV');
promoimage.setAttribute('src','//keenspot.com/images/headerbar-keenspotshop-twokindsvol5preorder.png');
promoimage.setAttribute('alt','TWOKINDS VOL. 5');

//promolink.setAttribute('href','https://bit.ly/34DhAES');
//promoimage.setAttribute('src','//keenspot.com/images/headerbar-marrymemovie.png');
//promoimage.setAttribute('alt','MARRY ME MOVIE');



//tpimage.setAttribute('src','http://n4403ad.doubleclick.net/ad/gn.keenspot.com/redirect;adid=242977127;sect=redirect;sz=1x1;ord='+rndcode);
}


if(selvar>=1){
/*
promolink.setAttribute('href','http://bit.ly/shoptwokinds');
promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-keenspotshop-twokindsvol4.gif');
promoimage.setAttribute('alt','TWOKINDS VOL. 4');
*/
/*promolink.setAttribute('href','http://bit.ly/WWEUkeenspot');
promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-expandeduniverse.png');
promoimage.setAttribute('alt','Expanded Universe');
*/
/*
promolink.setAttribute('href','http://bit.ly/2R9xL4y');
promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-keenspotshop-holiday2018.gif');
promoimage.setAttribute('alt','Holiday 2018');
*/
/*
promolink.setAttribute('href','http://bit.ly/yusx2w');
promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-sdcc2019.png');
promoimage.setAttribute('alt','SDCC 2019');
*/
/*
promolink.setAttribute('href','http://bit.ly/yusx2w');
promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-keenspotshop-jul2019a.gif');
promoimage.setAttribute('alt','Keenspot Shop July 2019');
*/
/*promolink.setAttribute('href','http://bit.ly/2R9xL4y');
promoimage.setAttribute('src','http://cdn.keenspot.com/images/headerbar-treatandtreat.gif');
promoimage.setAttribute('alt','Halloween 2019');
*/
/*
promolink.setAttribute('href','http://bit.ly/3pBqwzK');
promoimage.setAttribute('src','//keenspot.com/images/headerbar-thecw-supermanandlois.png');
promoimage.setAttribute('alt','CW Superman and Lois');
*/

//promolink.setAttribute('href','https://bit.ly/3nn36R6');
//promoimage.setAttribute('src','//keenspot.com/images/headerbar-ninjasandrobots.gif');
//promoimage.setAttribute('alt','NINJAS AND ROBOTS');

//promolink.setAttribute('href','https://bit.ly/4f7mXf1');
//promoimage.setAttribute('src','//keenspot.com/images/headerbar-christmaswithgrubbs.png');
//promoimage.setAttribute('alt','GRUBBS');


}
/*
if(selvar==2){
promolink.setAttribute('href','');
promoimage.setAttribute('src','');
promoimage.setAttribute('alt','Click Here');
}
*/


/*
if(selvar==2){
promolink.setAttribute('href','http://bit.ly/1VxFapG');
promoimage.setAttribute('src','//www.keenspot.com/images/headerbar-keenspotshop1.gif');
promoimage.setAttribute('alt','Keenspot Shop');
}
if(selvar>=3){
promolink.setAttribute('href','http://bit.ly/yusx2w');
promoimage.setAttribute('src','//www.keenspot.com/images/headerbar-sdcc2018.png');
promoimage.setAttribute('alt','SDCC 2018');
}
*/



if(selvar=="GEONONUS"){

}
if(selvar=="TIMER"){
promolink.setAttribute('href','http://bit.ly/AqoQHg');
promoimage.setAttribute('src','//www.keenspot.com/images/headerbar-sopapipa.gif');
promoimage.setAttribute('alt',"SOPA Censorship protest day");
}



if(1){
addtodrop("Select a Spot!"," ");
addtodrop("=NOW UPDATING="," ");


//addtodrop("+EV","http://www.plusev.net");
//addtodrop("27 (Twenty-Seven)","http://twenty-seven.keenspot.com");
//addtodrop("AntiHero for Hire","http://antiheroforhire.com");
//addtodrop("Avengelyne","http://avengelyne.keenspot.com");
//addtodrop("Banzai Girl","http://banzaigirl.keenspot.com");
//addtodrop("Barker","http://barkercomic.keenspot.com");
//addtodrop("Brawl in the Family","http://brawlinthefamily.keenspot.com");
//addtodrop("Buzzboy","http://buzzboy.keenspot.com");
//addtodrop("Clich� Flamb�","http://clicheflambe.keenspot.com/");
addtodrop("Chopping Block","http://choppingblock.keenspot.com");
//addtodrop("Count Your Sheep","http://www.countyoursheep.com");
//addtodrop("Crow Scare","http://www.crowscare.com");
//addtodrop("Dreamless","http://dreamless.keenspot.com");
//addtodrop("Everything Jake","http://everythingjake.keenspot.com");
//addtodrop("Exposure","http://exposure.keenspot.com");
//addtodrop("Fall Out Toy Works","http://fallouttoyworks.keenspot.com");
//addtodrop("Flipside","http://flipside.keenspot.com");
//addtodrop("Friar and Brimstone","http://friarandbrimstone.keenspot.com");
//addtodrop("The First Daughter","http://thefirstdaughter.keenspot.com");
//addtodrop("Gene Catlow","http://genecatlow.keenspot.com");
//addtodrop("The God Child","http://godchild.keenspot.com");

addtodrop("God Mode","http://godmode.keenspot.com/d/20210704.html");
//addtodrop("Green Wake","http://greenwake.keenspot.com");
//addtodrop("Head Trip","http://headtrip.keenspot.com");
//addtodrop("Hoax Hunters","http://hoaxhunters.keenspot.com");
addtodrop("Hunters of Salamanstra","http://salamanstra.keenspot.com");
//addtodrop("The Hope Virus","http://hopevirus.keenspot.com");

//addtodrop("Hero by Night","http://herobynight.keenspot.com");
//addtodrop("In Here","http://inhere.keenspot.com/");

//addtodrop("Jade Warriors","http://jadewarriors.keenspot.com");
//addtodrop("Katrina","http://katrina.keenspot.com");

//addtodrop("Landis","http://landis.keenspot.com");
//addtodrop("The Lounge","http://thelounge.keenspot.com");
//addtodrop("Last Blood","http://lastblood.keenspot.com");
//addtodrop("Luther Strode","http://lutherstrode.keenspot.com");

//addtodrop("Makeshift Miracle","http://makeshiftmiracle.keenspot.com");
//addtodrop("Marksmen","http://marksmen.keenspot.com");
//addtodrop("Marry Me","http://marryme.keenspot.com");
//addtodrop("Medusa\'s Daughter","http://medusa.keenspot.com");
//addtodrop("Monster Massacre","http://monstermassacre.keenspot.com");
//addtodrop("Mystic Revolution","http://mysticrevolution.keenspot.com");
addtodrop("Newshounds","http://www.newshounds.com");
addtodrop("No Pink Ponies","http://nopinkponies.keenspot.com");
//addtodrop("Porcelain","http://porcelain.keenspot.com");
//addtodrop("Punch an\' Pie ","http://punchanpie.keenspot.com");
//addtodrop("Out There","http://outtherecomic.com");
//addtodrop("QUILTBAG","http://quiltbag.keenspot.com");
//addtodrop("Road Waffles","http://roadwaffles.keenspot.com");

//addtodrop("Red Spike","http://redspike.keenspot.com");
//addtodrop("Rumble Fall","http://rumblefall.keenspot.com");
//addtodrop("Samurai\'s Blood","http://samuraisblood.keenspot.com");
//addtodrop("Shockwave Darkside","http://shockwave.keenspot.com");
//addtodrop("Sharky","http://sharky.keenspot.com");
//addtodrop("Something Happens","http://www.somethinghappens.net");
//addtodrop("Sore Thumbs","http://www.sorethumbsonline.com");
//addtodrop("Striptease","http://striptease.keenspot.com");
//addtodrop("Supernovas","http://supernovas.keenspot.com");
addtodrop("Superosity","http://www.superosity.com");
addtodrop("Twokinds","http://twokinds.keenspot.com");
//addtodrop("The Vault","http://thevault.keenspot.com");

//addtodrop("Wayward Sons","http://waywardsons.keenspot.com");
//addtodrop("Weirding Willows","http://weirdingwillows.keenspot.com/");
//addtodrop("Yirmumah","http://yirmumah.keenspot.com");
//addtodrop("You Damn Kid","http://youdamnkid.keenspot.com");

addtodrop("=BINGE OLD FAVES="," ");
addtodrop(" Brawl In The Family","http://brawlinthefamily.keenspot.com/comic/theshowdown/");
addtodrop(" RPG World","http://rpgworld.keenspot.com/d/20000827.html");
addtodrop(" Marry Me","http://marryme.keenspot.com/d/20120731.html");
addtodrop(" Avengelyne","http://avengelyne.keenspot.com/d/20111212.html");
addtodrop(" Striptease","http://striptease.keenspot.com/d/20000930.html");
addtodrop(" Out There","http://outthere.keenspot.com/d/20060612.html");
addtodrop(" Count Your Sheep","http://countyoursheep.keenspot.com/d/20030611.html");
addtodrop(" Chopping Block","http://choppingblock.keenspot.com/d/20000725.html");
addtodrop(" Dreamless","http://dreamless.keenspot.com/d/20090105.html");
addtodrop(" Fall Out Toy Works","http://fallouttoyworks.keenspot.com/d/20120326.html");
addtodrop(" Sore Thumbs","http://sorethumbs.keenspot.com/d/20040308.html");
addtodrop(" Mystic Revolution","http://mysticrevolution.keenspot.com/index.php?cid=1");
addtodrop(" Punch an\' Pie","http://punchanpie.keenspot.com/daily/20070226.html");
addtodrop(" The Lounge","http://thelounge.keenspot.com/d/20020601.html");
addtodrop(" Gene Catlow","http://genecatlow.keenspot.com/d/20000717.html");
addtodrop(" Makeshift Miracle","http://makeshiftmiracle.keenspot.com/d/20110926.html");
addtodrop(" God Mode","http://godmode.keenspot.com/d/20050915.html");


}


}

buildbar();
document.body.insertBefore(ksheaderdiv,document.body.firstChild);
if(typeof _gaq=="undefined"){

}
else{
 _gaq.push(['kg._setAccount', 'UA-28843192-1']);
 _gaq.push(['kg._setDomainName', '.keenspot.com']);
 _gaq.push(['kg._setAllowLinker', true]); 

 _gaq.push(['kg._trackPageview']);
} 
//beforeunload should be used to bookmark location when leaving.
function savemyspot(){

localStorage.setItem('savemylastpage',self.location);

}
function restoremyspot(){
self.location=localStorage.getItem('savemylastpage');

}
function killbill(){
/* Comic rippers are not welcome. I'm being nice and not breaking it entirely. No preloading. No tampering with ad placement. 
*/
if(document.getElementById("wcr_div"))
{
var unfixprev=document.getElementById("wcr_btn-1");
unfixprev.setAttribute('onclick',"top.location.href=\""+unfixprev.title+"\"");
var unfixnext=document.getElementById("wcr_btn1");
unfixnext.setAttribute('onclick',"top.location.href=\""+unfixnext.title+"\"");
var zmz=document.getElementById("wcr_imagenes");
zmz.parentNode.removeChild(zmz);

var ztz=document.getElementById("wcr_links_imgs");
ztz.parentNode.removeChild(ztz);
var zry=document.getElementById("wcr_btnfit");
zry.parentNode.removeChild(zry);
var zrz=document.getElementById("wcr_btnlayout");
zrz.parentNode.removeChild(zrz);
var qry=document.getElementById("wcr_imagen");
qry.id="c"+(Math.ceil(Math.random() * 256)-1)+"i";

var qrz=document.getElementById("wcr_div");
qrz.id="c"+(Math.ceil(Math.random() * 256)-1)+"";
}

/* Bad behavior by Wibya */
if(document.getElementById("div_shadow"))
{
var ctos=document.getElementById("div_shadow");
ctos.parentNode.removeChild(ctos);

}
}


function bucheck(){
killbill();
(function(){
var event_names = { 
    "click" :   "" ,
    "tweet" :  "",
    "retweet" : "source_tweet_id",
    "follow" : "screen_name",
    "favorite" : "tweet_id"
    };

for(var event_name in event_names)
{
    if(event_names.hasOwnProperty(event_name)){
	
if(typeof twttr != "undefined"){
	twttr.events.bind(event_name, function(intent_event)
	{
	    if(intent_event)
	    {
		var label = intent_event.type==="click" ? intent_event.region : (intent_event.data) ? intent_event.data[event_names[intent_event.type]] : "" ;
		_gaq.push(["_trackEvent", "twitter_web_intents", intent_event.type, label ]);
		_gaq.push(["kg._trackEvent", "twitter_web_intents", intent_event.type, label ]);
	    }
	});
}
    }
}
}());


var St = document.getElementsByTagName('style');
for( var x = 0; St[x]; x++ ) {
if(St[x].parentNode!=document.head){
St[x].parentNode.removeChild(St[x]);
}
}

var QQt = document.getElementsByTagName('script');

for( var x = 0; QQt[x]; x++ ) {
if(typeof cw_Process == 'undefined' && QQt[x].src.match(/contextweb/) )
{

var zz=document.createElement('img');
var zzx=document.createElement('img');
if(QQt[x].src.match(/cwwidth=728/)){
zzx.setAttribute('width','728');
zzx.setAttribute('height','90');
zzx.setAttribute('border','0');
zz.setAttribute('width','1');
zz.setAttribute('height','1');
zz.setAttribute('border','0');

zzx.src="/blocked728.gif";
zz.src="//www.keenspot.com/images/bu728.gif";
}
if(QQt[x].src.match(/cwwidth=300/)){
zzx.setAttribute('width','300');
zzx.setAttribute('height','250');
zzx.setAttribute('border','0');
zz.setAttribute('width','1');
zz.setAttribute('height','1');
zz.setAttribute('border','0');
zzx.src="/blocked300.gif";
zz.src="//www.keenspot.com/images/bu300.gif";

}
if(QQt[x].src.match(/cwwidth=160/)){
zzx.setAttribute('width','160');
zzx.setAttribute('height','600');
zzx.setAttribute('border','0');
zz.setAttribute('width','1');
zz.setAttribute('height','1');
zz.setAttribute('border','0');
zzx.src="/blocked160.gif";
zz.src="//www.keenspot.com/images/bu160.gif";
}
QQt[x].parentNode.insertBefore(zz,QQt[x]);
//QQt[x].parentNode.insertBefore(zzx,QQt[x]);
QQt[x].parentNode.removeChild(QQt[x]);
}
}


}
window.addEventListener("load",bucheck,true);
localStorage.setItem('headeron',true);
if(localStorage.getItem('autosavenav')==true){
savemyspot();
}
//if('ontouchstart' in document.documentElement && localStorage.getItem('usetouchnavi')==true){

//}
