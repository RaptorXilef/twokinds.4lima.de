document.write('<a href=\"https://bit.ly/2XDeQnV\"><img src=\"http://www.keenspot.com/data/news-twokinds-oct2021.png\" border=\"0\"></a>');
